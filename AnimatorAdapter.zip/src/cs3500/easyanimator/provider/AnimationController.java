package cs3500.easyanimator.provider;

import java.awt.event.ActionListener;

public interface AnimationController extends ActionListener {

}
